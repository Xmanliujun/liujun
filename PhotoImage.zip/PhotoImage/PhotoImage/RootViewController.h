//
//  RootViewController.h
//  PhotoImage
//
//  Created by XmL on 13-5-31.
//  Copyright (c) 2013年 XmL. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <QuartzCore/QuartzCore.h>
#import <MobileCoreServices/UTCoreTypes.h>
#import <AVFoundation/AVFoundation.h>
#import <CoreAudio/CoreAudioTypes.h>


@interface RootViewController : UIViewController
<UINavigationControllerDelegate,UIVideoEditorControllerDelegate,UIImagePickerControllerDelegate,UIAlertViewDelegate,AVAudioPlayerDelegate>
{

    UIImageView *myTransitionView;
	UIImageView *bottomBarImageView;
    UIImage *originalImage;
    UIImagePickerController *currentPickerController;
    UIButton * photoButton;
    
    
    UIButton * avButton;
    UIButton * avTwButton;
    NSURL *recordedFile;
    AVAudioPlayer *player;
    AVAudioRecorder *recorder;
    BOOL isRecording;
    
    
   
}
@property (nonatomic) BOOL isRecording;



@end
