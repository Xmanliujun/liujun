//
//  RootViewController.m
//  PhotoImage
//
//  Created by XmL on 13-5-31.
//  Copyright (c) 2013年 XmL. All rights reserved.
//

#import "RootViewController.h"

@interface RootViewController ()

@end

@implementation RootViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

#pragma mark UIImagePickerControllerDelegate
- (void)imagePickerController:(UIImagePickerController *)picker didFinishPickingMediaWithInfo:(NSDictionary *)info{
	
    NSLog(@"dic  is  %@",info);
    NSString *mediaType = [info objectForKey:UIImagePickerControllerMediaType];
	
    if ([mediaType isEqualToString:@"public.image"]){
		originalImage= [info objectForKey:UIImagePickerControllerOriginalImage];
        [picker dismissViewControllerAnimated:YES completion:NULL];
        myTransitionView.image = originalImage;
        CGFloat floatQuality = 100.0;
        NSData * data = UIImageJPEGRepresentation(originalImage, floatQuality);
        NSLog(@"data  length is %d",[data length]);
	}

    
    
}

- (void)imagePickerControllerDidCancel:(UIImagePickerController *)picker{
    
    [picker dismissViewControllerAnimated:YES completion:NULL];
    
}

-(void)photoButtonImage:(UIButton * )btn
{

    if ([UIImagePickerController isSourceTypeAvailable:UIImagePickerControllerSourceTypeCamera]) {
				UIImagePickerController *imagePickerController=[[UIImagePickerController alloc] init];
		imagePickerController.sourceType=UIImagePickerControllerSourceTypeCamera;
		imagePickerController.delegate = self;
		imagePickerController.modalTransitionStyle=UIModalTransitionStyleFlipHorizontal;
		currentPickerController = imagePickerController;
        [self presentViewController:imagePickerController animated:YES completion:NULL];
	}



}


-(void)playPause:(UIButton * )btn
{
    //停止
    if([player isPlaying])
    {
        [player pause];
        [avButton setTitle:@"Play" forState:UIControlStateNormal];
    }
    //播放
    else
    {
        [player play];
        [avButton setTitle:@"Pause" forState:UIControlStateNormal];
    }


}

-(void)startStopRecording:(UIButton *)btn
{
    
    //开始录音
    if(!self.isRecording)
    {
        self.isRecording = YES;
        [avTwButton setTitle:@"完成" forState:UIControlStateNormal];
        [avButton setEnabled:NO];
        [avButton.titleLabel setAlpha:0.5];
        //录制内容存到recordedFile中
        recorder = [[AVAudioRecorder alloc] initWithURL:recordedFile settings:nil error:nil];
        [recorder prepareToRecord];
        [recorder record];
        player = nil;
    }
    
    //录音完成
    else
    {
        self.isRecording = NO;
        [avTwButton setTitle:@"录音" forState:UIControlStateNormal];
        [avButton setEnabled:YES];
        [avButton.titleLabel setAlpha:1];
        [recorder stop];
        recorder = nil;
        
        NSError *playerError;
        //播放器获取 录制的recoededFile内容 
        player = [[AVAudioPlayer alloc] initWithContentsOfURL:recordedFile error:&playerError];
        
        if (player == nil)
        {
            NSLog(@"ERror creating player: %@", [playerError description]);
        }
        player.delegate = self;
    }

 
    
    
    
}

//播放完成后button回复播放状态
- (void)audioPlayerDidFinishPlaying:(AVAudioPlayer *)player successfully:(BOOL)flag
{
    [avButton setTitle:@"Play" forState:UIControlStateNormal];
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    
    photoButton = [UIButton buttonWithType:UIButtonTypeRoundedRect];
    photoButton.frame = CGRectMake(20, 20, 80, 40);
    [photoButton setTitle:@"照相" forState:UIControlStateNormal];
    [photoButton addTarget:self action:@selector(photoButtonImage:) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:photoButton];
    
    myTransitionView = [[UIImageView alloc] init];
    myTransitionView.frame = CGRectMake(5, 80, 310,350);
    [self.view addSubview:myTransitionView];
    
    
    avButton = [UIButton buttonWithType:UIButtonTypeRoundedRect];
    avButton.frame = CGRectMake(120, 20, 80, 40);
    [avButton setTitle:@"play" forState:UIControlStateNormal];
    [avButton addTarget:self action:@selector(playPause:) forControlEvents:UIControlEventTouchUpInside];
    [avButton setEnabled:NO];
    avButton.titleLabel.alpha = 0.5;
    [self.view addSubview:avButton];
    
    avTwButton = [UIButton buttonWithType:UIButtonTypeRoundedRect];
    avTwButton.frame = CGRectMake(220, 20, 80, 40);
    [avTwButton setTitle:@"录音" forState:UIControlStateNormal];
    [avTwButton addTarget:self action:@selector(startStopRecording:) forControlEvents:UIControlEventTouchUpInside];
    
    [self.view addSubview:avTwButton];
    
    
    //设置录音所需要的东东
    recordedFile = [NSURL fileURLWithPath:[NSTemporaryDirectory() stringByAppendingString:@"RecordedFile"]];
    
    AVAudioSession *session = [AVAudioSession sharedInstance];
    
    NSError *sessionError;
    [session setCategory:AVAudioSessionCategoryPlayAndRecord error:&sessionError];
    
    if(session == nil)
        NSLog(@"Error creating session: %@", [sessionError description]);
    else
        [session setActive:YES error:nil];
    
    
    
    
    
    
    
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
